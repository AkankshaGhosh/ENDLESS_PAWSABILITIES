
TITLE:
ENDLESS PAWSABILITIES - A Website Prototype for our 6th Semester Minor Project

AUTHOR:
1905447

CREDITS:

FreeHTML5
http://freehtml5.co/

Bootstrap
http://getbootstrap.com/

jQuery
http://jquery.com/

jQuery Easing
http://gsgd.co.uk/sandbox/jquery/easing/

Modernizr
http://modernizr.com/

Google Fonts
https://www.google.com/fonts/

Google Map
http://maps.google.com

Icomoon
https://icomoon.io/app/

Respond JS
https://github.com/scottjehl/Respond/blob/master/LICENSE-MIT

animate.css
http://daneden.me/animate

jQuery Waypoint
https://github.com/imakewebthings/waypoints/blog/master/licenses.txt

Superfish Menu
http://users.tpg.com.au/j_birch/plugins/superfish/examples/

hoverIntent
https://github.com/briancherne/jquery-hoverIntent

Stellar Parallax
http://markdalgleish.com/projects/stellar.js/

Demo Images
http://unsplash.com/
